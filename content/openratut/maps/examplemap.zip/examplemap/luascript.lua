WorldLoaded = function ()
	
end

Tick = function ()
	
end